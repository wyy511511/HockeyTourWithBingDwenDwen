import SwiftUI
//#-learning-task(storyView)

/*#-code-walkthrough(StoryView.storyView)*/
struct StoryView: View {
    /*#-code-walkthrough(StoryView.storyView)*/
    var body: some View {
        VStack {
            Text("My Story")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            /*#-code-walkthrough(StoryView.scrollView)*/
            ScrollView {
                /*#-code-walkthrough(StoryView.text)*/
                /*#-code-walkthrough(StoryView.loremIpsum)*/
                Text(information.story)
                /*#-code-walkthrough(StoryView.text)*/
                /*#-code-walkthrough(StoryView.loremIpsum)*/
                    .font(.body)
                    .padding()
            }
            /*#-code-walkthrough(StoryView.scrollView)*/
        }
        .padding([.top, .bottom], 50)
    }
}

struct StoryView_Previews: PreviewProvider {
    static var previews: some View {
        StoryView()
    }
}
