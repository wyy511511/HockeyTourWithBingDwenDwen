import SwiftUI
//https://www.editcode.net/ask/148217 
//struct ContentView: View {
//    var body: some View {
//        VStack {
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundColor(.accentColor)
//            Text("Hello, world!")
//        }
//    }
//}
//

import SwiftUI
import RealityKit
import ARKit
import Combine
//
//struct ContentView : View {
//    @State var showingPreview = true
//    var body: some View {
//        ZStack{
//            HStack{
//                Button("在ARView中预览模型") {
//                    self.showingPreview.toggle()
//                }
//                .padding(.all)
//                .background(Color.orange)
//                .sheet(isPresented: $showingPreview) {
//                ARViewContainer().edgesIgnoringSafeArea(.all)
//                }
//            }
//
//            //ARQuickLookView(fileName: "untitled",allowScaling:true).edgesIgnoringSafeArea(.all)
//            Text("hhhh")
//        }
// //这样一个单一界面可以成功
//    }
//}

 

import SwiftUI
struct ARContentView : View {
    @State var showingPreview = false
    @State var showingPreviewIce = false
    @State var showingARViewPreview = false
    @State var showingARViewPreviewIce = false
    var body: some View {
        VStack {
            
            Button("View Bingdwendwen with ARQuickLook") {
                self.showingPreview.toggle()
            }
            .padding(.all)
            .background(Color.yellow)
            .sheet(isPresented: $showingPreview) {
                VStack {
                    HStack {
                        Button("Close") {
                            self.showingPreview.toggle()
                        }
                        Spacer()
                    }
                    .padding()
                    .background(Color.red)
                    ARQuickLookView(fileName: "bdd",allowScaling:true).edgesIgnoringSafeArea(.all)
                }
                .edgesIgnoringSafeArea(.all)
            }
            
            
            Button("View Bingdwendwen in AR with the iPad's camera") {
                self.showingARViewPreview.toggle()
            }
            .padding(.all)
            .background(Color.orange)
            .sheet(isPresented: $showingARViewPreview) {
                VStack {
                    HStack {
                        Button("Close") {
                            self.showingARViewPreview.toggle()
                        }
                        Spacer()
                    }
                    .padding()
                    .background(Color.red)
//                    ARQuickLookView(fileName: "untitled",allowScaling:true).edgesIgnoringSafeArea(.all)
                    ARViewContainer().edgesIgnoringSafeArea(.all)
                }
                .edgesIgnoringSafeArea(.all)
            }
            
            
            ////////
            Button("View the hockey rink in AR with the iPad's camera") {
                self.showingARViewPreviewIce.toggle()
            }
            .padding(.all)
            .background(Color.orange)
            .sheet(isPresented: $showingARViewPreviewIce) {
                VStack {
                    HStack {
                        Button("Close") {
                            self.showingARViewPreviewIce.toggle()
                        }
                        Spacer()
                    }
                    .padding()
                    .background(Color.red)
//                    ARQuickLookView(fileName: "untitled",allowScaling:true).edgesIgnoringSafeArea(.all)
                    ARViewContainerIce().edgesIgnoringSafeArea(.all)
                }
                .edgesIgnoringSafeArea(.all)
            }
            
            
            Button("View the hockey rink with ARQuickLook") {
                self.showingPreviewIce.toggle()
            }
            .padding(.all)
            .background(Color.yellow)
            .sheet(isPresented: $showingPreviewIce) {
                VStack {
                    HStack {
                        Button("Close") {
                            self.showingPreviewIce.toggle()
                        }
                        Spacer()
                    }
                    .padding()
                    .background(Color.red)
                    ARQuickLookView(fileName: "ice",allowScaling:true).edgesIgnoringSafeArea(.all)
                }
                .edgesIgnoringSafeArea(.all)
            }
            
            
            
                
            
            ScrollView{
                Text("SwiftPM app can't enable ARQuickLook in some devices, so if you want to zoom in and out the 3D model and take a photo with Bing Dwen Dwen, please follow the guide below.")
                    .foregroundColor(Color.red)
                
                VStack{
                    Text("Step1")
                        .font(.title3)
                    Text("Open the playground project file")
                    Text("Step2")
                        .font(.title3)
                    Text("Split screen with files applications")
                    Image("bddar2")
                        .resizable()
                        .scaledToFit()
                    VStack{
                        Text("Step3")
                            .font(.title3)
                        Text("Drag USDZ model to your device")
                        Text("Step4")
                            .font(.title3)
                        Text("Open USDZ model in Files app")
                        Text("Step5")
                            .font(.title3)
                    }
                    Text("Enjoy it! If you cannot turn on the camera, repeat step 5 ")
                    Image("bddar1")
                        .resizable()
                        .scaledToFit()
                
                    
                    
                }
                
            }
            
            
            
            
            
        }
        .edgesIgnoringSafeArea(.all)
    }
}


struct ARViewContainer: UIViewRepresentable {
    
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        config.worldAlignment = .gravity
        arView.session.run(config, options:[ ])
        arView.session.delegate = arView
        arView.loadModel()
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
    }
}

extension ARView : ARSessionDelegate{
    func loadModel(){
        let planeAnchor = AnchorEntity()
        //同步加载
        do {
            let usdzPath = "bdd"
            let modelEntity =  try ModelEntity.loadModel(named: usdzPath)
            print("加载成功！")
            planeAnchor.addChild(modelEntity)
        } catch {
            print("找不到文件")
        }
        //异步加载
        /*
        let usdzPath = "toy_drummer"
        var cancellable: AnyCancellable? = nil
        cancellable = ModelEntity.loadModelAsync(named: usdzPath)
            .sink(receiveCompletion: { error in
                print("发生错误: \(error)")
                cancellable?.cancel()
            }, receiveValue: { entity in
                planeAnchor.addChild(entity)
                cancellable?.cancel()
            })
        */
        self.scene.addAnchor(planeAnchor)
    }
    
    func loadModelIce(){
        let planeAnchor = AnchorEntity()
        //同步加载
        do {
            let usdzPath = "ice"
            let modelEntity =  try ModelEntity.loadModel(named: usdzPath)
            print("加载成功！")
            planeAnchor.addChild(modelEntity)
        } catch {
            print("找不到文件")
        }
        //异步加载
        /*
        let usdzPath = "toy_drummer"
        var cancellable: AnyCancellable? = nil
        cancellable = ModelEntity.loadModelAsync(named: usdzPath)
            .sink(receiveCompletion: { error in
                print("发生错误: \(error)")
                cancellable?.cancel()
            }, receiveValue: { entity in
                planeAnchor.addChild(entity)
                cancellable?.cancel()
            })
        */
        self.scene.addAnchor(planeAnchor)
    }
}


struct ARViewContainerIce: UIViewRepresentable {
    
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        config.worldAlignment = .gravity
        arView.session.run(config, options:[ ])
        arView.session.delegate = arView
        arView.loadModelIce()
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
    }
}

/**
#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
 **/
