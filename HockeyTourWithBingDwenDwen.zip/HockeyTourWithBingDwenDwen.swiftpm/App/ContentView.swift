import SwiftUI
//#-learning-task(contentView)

/*#-code-walkthrough(ContentView.introducingMe)*/
struct ContentView: View {
    /*#-code-walkthrough(ContentView.introducingMe)*/
    /*#-code-walkthrough(ContentView.body)*/
    var body: some View {
        /*#-code-walkthrough(ContentView.body)*/
        /*#-code-walkthrough(ContentView.tabView)*/
        TabView {
            /*#-code-walkthrough(ContentView.homeTab)*/
            HomeView()
            /*#-code-walkthrough(ContentView.tabItem)*/
            .tabItem {
                Label("Home", systemImage: "person")
            }
            /*#-code-walkthrough(ContentView.homeTab)*/
            /*#-code-walkthrough(ContentView.tabItem)*/

//            StoryView()
//                .tabItem {
//                    Label("Story", systemImage: "book")
//                }
//
            FavoritesView()
                .tabItem {
                    Label("Rules Explained", systemImage: "star")
                }
            
            FunFactsView()
                .tabItem {
                    Label("Fun Cards", systemImage: "book")
                }
            
            ARContentView()
                .tabItem {
                    Label("AR", systemImage: "lasso.and.sparkles")
                }
            ARQuickLookView(fileName: "bdd",allowScaling:true).edgesIgnoringSafeArea(.all)
                .tabItem {
                    Label("Bing Dwen Dwen", systemImage: "hand.thumbsup")
                }
            QuestionView()
                .tabItem {
                    Label("QA", systemImage: "hand.thumbsup")
                }
        }
        /*#-code-walkthrough(ContentView.tabView)*/
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
