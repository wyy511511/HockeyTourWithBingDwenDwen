import SwiftUI
//#-learning-task(homeView)

/*#-code-walkthrough(HomeView)*/
struct HomeView: View {
    /*#-code-walkthrough(HomeView)*/
    
    var body: some View {
        /*#-code-walkthrough(HomeView.VStack)*/
        VStack {
        /*#-code-walkthrough(HomeView.VStack)*/
            /*#-code-walkthrough(HomeView.Text)*/
            Text("All About Bing Dwen Dwen with Hockey🏒️!!!")
            /*#-code-walkthrough(HomeView.Text)*/
                /*#-code-walkthrough(HomeView.Text.fontModifiers)*/
                .font(.largeTitle)
                .fontWeight(.bold)
                /*#-code-walkthrough(HomeView.Text.fontModifiers)*/
                /*#-code-walkthrough(HomeView.Text.padding)*/
                .padding()
                /*#-code-walkthrough(HomeView.Text.padding)*/
            Text("Welcome to experience the Hockey Explained with Bing Dwen Dwen!\nYou can view Hockey Rink Model and Bing Dwen Dwen use your iPad via ARKit and ARQuickLook!\n You can learn the terminology of hockey through cards and animations made by SwiftUI.")

            /*#-code-walkthrough(HomeView.Image)*/
            Image(information.image)
            /*#-code-walkthrough(HomeView.Image)*/
                /*#-code-walkthrough(HomeView.Image.resizable)*/
                .resizable()
                /*#-code-walkthrough(HomeView.Image.resizable)*/
                /*#-code-walkthrough(HomeView.Image.aspectRatio)*/
                .aspectRatio(contentMode: .fit)
                /*#-code-walkthrough(HomeView.Image.aspectRatio)*/
                /*#-code-walkthrough(HomeView.Image.cornerRadius)*/
                .cornerRadius(10)
                /*#-code-walkthrough(HomeView.Image.cornerRadius)*/
                .padding(40)

            Text(information.name)
                .font(.title)
        }
    }
    
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
