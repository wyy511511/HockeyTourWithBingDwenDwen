import SwiftUI
//#-learning-task(favoritesView)

/*#-code-walkthrough(FavoritesView.favorites)*/


//Image("Collin")
//    .resizable()
//    .frame(width: 60, height: 80)
//    .onTapGesture {
//        //withAnimation {
//        showingAnimationview.toggle()
//        //}
//    }

struct FavoritesView: View {
    /*#-code-walkthrough(FavoritesView.favorites)*/
    @State var showingTeamPlayerExplained = false
    @State var showingOffsidesExplained = false
    @State var showingCherrypickExplained = false
    @State var showingHybridIcingExplained = false
    @State var showingNoTouchIcingExplained = false
    @State var showingTouchIcingExplained = false
    @State var showingIceHockeyRinkExplained = false

    var body: some View {
        VStack {
            Text("Basic Rules")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 40)
            
            HStack {
                Button("Team Player") {
                    self.showingTeamPlayerExplained.toggle()
                }
                .frame(width: 70, height: 70)
                .cornerRadius(10)
                .padding(.all)
                .background(Color.orange)
                .sheet(isPresented: $showingTeamPlayerExplained) {
                    VStack {
                        HStack {
                            Button("Close") {
                                self.showingTeamPlayerExplained.toggle()
                            }
                            Spacer()
                        }
                        .padding()
                        .background(Color.red)
                        TeamPlayerExplained()
                    }
                    .edgesIgnoringSafeArea(.all)
            }
                
                Button("Ice Hockey Rink") {
                    self.showingIceHockeyRinkExplained.toggle()
                }
                .frame(width: 70, height: 70)
                .cornerRadius(10)
                .padding(.all)
                .background(Color.orange)
                .sheet(isPresented: $showingIceHockeyRinkExplained) {
                    VStack {
                        HStack {
                            Button("Close") {
                                self.showingIceHockeyRinkExplained.toggle()
                            }
                            Spacer()
                        }
                        .padding()
                        .background(Color.red)
                        IceHockeyRinkExplained()
                    }
                    .edgesIgnoringSafeArea(.all)
            }
                
                
            }
            
            
            
            
            VStack {
                Text("2 Common Infractions")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                .padding(.bottom, 40)
                
                HStack {
                    Text("Offsides")
                        .font(.title2)
                    
                    Button("Cherry Pick") {
                        self.showingCherrypickExplained.toggle()
                    }
                    .frame(width: 70, height: 70)
                    .cornerRadius(10)
                    .padding(.all)
                    .background(Color.yellow)
                    .sheet(isPresented: $showingCherrypickExplained) {
                        VStack {
                            HStack {
                                Button("Close") {
                                    self.showingCherrypickExplained.toggle()
                                }
                                Spacer()
                            }
                            .padding()
                            .background(Color.red)
                            CherrypickExplained()
                        }
                        .edgesIgnoringSafeArea(.all)
                    }
                    
                    
                    Button("Offsides") {
                        self.showingOffsidesExplained.toggle()
                    }
                    .frame(width: 70, height: 70)
                    .cornerRadius(10)
                    .padding(.all)
                    .background(Color.orange)
                    .sheet(isPresented: $showingOffsidesExplained) {
                        VStack {
//                            HStack {
//                                Button("Close") {
//                                    self.showingOffsidesExplained.toggle()
//                                }
//                                Spacer()
//                            }
//                            .padding()
//                            .background(Color.red)
                            OffsidesExplained()
                        }
//                        .edgesIgnoringSafeArea(.all)
                    }
                    
                    
                    
                }
                
                
                
                /*#-code-walkthrough(FavoritesView.composition)*/
                HStack {
                    Text("Icing")
                        .font(.title2)
                    
                    Button("TouchIcing") {
                        self.showingTouchIcingExplained.toggle()
                    }
                    .frame(width: 70, height: 70)
                    .cornerRadius(10)
                    .padding(.all)
                    .background(Color.yellow)
                    .sheet(isPresented: $showingTouchIcingExplained) {
                        VStack {
                            HStack {
                                Button("Close") {
                                    self.showingTouchIcingExplained.toggle()
                                }
                                Spacer()
                            }
                            .padding()
                            .background(Color.red)
                            TouchIcingExplained()
                        }
                        .edgesIgnoringSafeArea(.all)
                    }
                    
                    Button("NoTouchIcing") {
                        self.showingNoTouchIcingExplained.toggle()
                    }
                    .frame(width: 70, height: 70)
                    .cornerRadius(10)
                    .padding(.all)
                    .background(Color.yellow)
                    .sheet(isPresented: $showingNoTouchIcingExplained) {
                        VStack {
                            HStack {
                                Button("Close") {
                                    self.showingNoTouchIcingExplained.toggle()
                                }
                                Spacer()
                            }
                            .padding()
                            .background(Color.red)
                            NoTouchIcingExplained()
                        }
                        .edgesIgnoringSafeArea(.all)
                    }
                    
                    Button("Hybrid Icing") {
                        self.showingHybridIcingExplained.toggle()
                    }
                    .frame(width: 70, height: 70)
                    .cornerRadius(10)
                    .padding(.all)
                    .background(Color.yellow)
                    .sheet(isPresented: $showingHybridIcingExplained) {
                        VStack {
                            HStack {
                                Button("Close") {
                                    self.showingHybridIcingExplained.toggle()
                                }
                                Spacer()
                            }
                            .padding()
                            .background(Color.yellow)
                            HybridIcingExplained()
                        }
                        .edgesIgnoringSafeArea(.all)
                    }
                    
                }
                
                
                
                
            }

            
            
//            HStack {
//                /*#-code-walkthrough(FavoritesView.forEach)*/
//                ForEach(information.hobbies, id: \.self) { hobby in
//                    /*#-code-walkthrough(FavoritesView.image)*/
//                    Image(systemName: hobby)
//                        .resizable()
//                        .frame(maxWidth: 80, maxHeight: 60)
//
//                    /*#-code-walkthrough(FavoritesView.image)*/
//
//                }
//                /*#-code-walkthrough(FavoritesView.forEach)*/
//                .padding()
//            }
//            .padding()
//            /*#-code-walkthrough(FavoritesView.composition)*/

//            Text("Foods")
//                .font(.title2)
//
//            HStack(spacing: 60) {
//                ForEach(information.foods, id: \.self) { food in
//                    Text(food)
//                        .font(.system(size: 48))
//                }
//            }
//            .padding()
//
//            Text("Favorite Colors")
//                .font(.title2)
//
//            HStack(spacing: 30) {
//                ForEach(information.colors, id: \.self) { color in
//                    color
//                        .frame(width: 70, height: 70)
//                        .cornerRadius(10)
//                }
//            }
//            .padding()
            
            
            
            
            
        }
    }
}

struct FavoritesView_Previews: PreviewProvider {
    static var previews: some View {
        FavoritesView()
    }
}
