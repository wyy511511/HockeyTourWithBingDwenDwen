//
//  AnimationSpeed.swift
//  Animations
//
//  Created by Lebus on 2022/4/16.
//

import SwiftUI

struct AnimationSpeed: View {
    @State private var movexDistance: CGFloat = 0
    @State private var moveyDistance: CGFloat = 0
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Image(systemName: "heart")
                    .font(.system(size: 50))
                    .offset(x: movexDistance, y: moveyDistance)// 把这个从10改到150才意识到这个大概只是起点。以及 y的150幅度小于x的80
                    //缓进缓出easeInOut
                    .animation(.easeIn(duration: 4), value: movexDistance)
                Spacer()
            }
            Button("点击移动爱心") {
                movexDistance += 80
                moveyDistance += 80

            }.font(.title)
            
//            let filePath = NSHomeDirectory() + "/Documents/hangge.png"
//            let image = UIImage(named: "Collin")
//            let data:Data = UIImagePNGRepresentation(image!)!
//            try? data.write(to: URL(fileURLWithPath: filePath))
//
        }
    }
}

struct AnimationSpeed_Previews: PreviewProvider {
    static var previews: some View {
        AnimationSpeed()
    }
}
