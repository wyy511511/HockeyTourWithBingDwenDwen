import SwiftUI
//#-learning-task(questionView)

/*#-code-walkthrough(questionView.intro)*/
struct QuestionView: View {
    /*#-code-walkthrough(questionView.intro)*/

    var body: some View {
        /*#-code-walkthrough(questionView.navigationView)*/
        NavigationView {
            /*#-code-walkthrough(questionView.questionPageView)*/
            QuestionPageView(question: question, pageIndex: 0)
            /*#-code-walkthrough(questionView.questionPageView)*/
        }
        /*#-code-walkthrough(questionView.navigationView)*/
        .navigationViewStyle(.stack)
    }
}
struct QuestionView_Previews: PreviewProvider {
//struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        QuestionView()
    }
}
