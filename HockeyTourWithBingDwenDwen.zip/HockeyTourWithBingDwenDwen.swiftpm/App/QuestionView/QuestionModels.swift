import Foundation
//#-learning-task(dataModel)

/*#-code-walkthrough(Models.Question)*/
struct Question {
    /*#-code-walkthrough(Models.Question)*/
    
    /*#-code-walkthrough(Models.Question.pagesProperty)*/
    let pages: [QuestionPage]
    /*#-code-walkthrough(Models.Question.pagesProperty)*/

    subscript(_ pageIndex: Int) -> QuestionPage {
        return pages[pageIndex]
    }
}

/*#-code-walkthrough(Models.QuestionPage)*/
struct QuestionPage {
    let text: String
    
    let choices: [Choice]
    
    init(_ text: String, choices: [Choice]) {
        self.text = text
        self.choices = choices
    }
}
/*#-code-walkthrough(Models.QuestionPage)*/

/*#-code-walkthrough(Models.Choice)*/
struct Choice {
    /*#-code-walkthrough(Models.Choice.textProperty)*/
    let text: String
    /*#-code-walkthrough(Models.Choice.textProperty)*/
    /*#-code-walkthrough(Models.Choice.destinationProperty)*/
    let destination: Int
    /*#-code-walkthrough(Models.Choice.destinationProperty)*/
}
/*#-code-walkthrough(Models.Choice)*/
