import SwiftUI
//#-learning-task(questionWithHiquestion)

/*#-code-walkthrough(NonlinearQuestion)*/
struct QuestionPageView: View {
    /*#-code-walkthrough(NonlinearQuestion)*/

    /*#-code-walkthrough(NonlinearQuestion.questionProperty)*/
    let question: Question
    /*#-code-walkthrough(NonlinearQuestion.questionProperty)*/
    /*#-code-walkthrough(NonlinearQuestion.pageIndexProperty)*/
    let pageIndex: Int
    /*#-code-walkthrough(NonlinearQuestion.pageIndexProperty)*/

    var body: some View {
        /*#-code-walkthrough(NonlinearQuestion.VStack)*/
        VStack {
            /*#-code-walkthrough(NonlinearQuestion.VStack)*/
            /*#-code-walkthrough(NonlinearQuestion.ScrollView)*/
            ScrollView {
                /*#-code-walkthrough(NonlinearQuestion.Text)*/
                Text(question[pageIndex].text)
                /*#-code-walkthrough(NonlinearQuestion.Text)*/
            }
            /*#-code-walkthrough(NonlinearQuestion.ScrollView)*/
            
            /*#-code-walkthrough(NonlinearQuestion.ForEach)*/
            ForEach(question[pageIndex].choices, id: \Choice.text) { choice in
                /*#-code-walkthrough(NonlinearQuestion.ForEach)*/
                /*#-code-walkthrough(NonlinearQuestion.navigationLink)*/
                NavigationLink(destination: QuestionPageView(question: question, pageIndex: choice.destination)) {
                /*#-code-walkthrough(NonlinearQuestion.navigationLink)*/
                /*#-code-walkthrough(NonlinearQuestion.navigationLink.label)*/
                    /*#-code-walkthrough(NonlinearQuestion.navigationLink.label.text)*/
                    Text(choice.text)
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    /*#-code-walkthrough(NonlinearQuestion.navigationLink.label.text)*/
                    /*#-code-walkthrough(NonlinearQuestion.navigationLink.label.modifiers)*/
                        .padding()
                        .background(Color.gray.opacity(0.25))
                        .cornerRadius(8)
                    /*#-code-walkthrough(NonlinearQuestion.navigationLink.label.modifiers)*/
                    /*#-code-walkthrough(NonlinearQuestion.navigationLink.label)*/
                }
            }
        }
        .padding()
        /*#-code-walkthrough(NonlinearQuestion.VStack.navigationModifiers)*/
        .navigationTitle("Page \(pageIndex + 1)")
        .navigationBarTitleDisplayMode(.inline)
        /*#-code-walkthrough(NonlinearQuestion.VStack.navigationModifiers)*/
    }
}

struct NonlinearQuestion_Previews: PreviewProvider {
    static var previews: some View {
        QuestionPageView(question: question, pageIndex: 0)
    }
}
