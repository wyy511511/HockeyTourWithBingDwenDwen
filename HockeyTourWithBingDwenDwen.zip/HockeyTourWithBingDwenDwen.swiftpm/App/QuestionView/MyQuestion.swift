import Foundation
import SwiftUI
//#-learning-task(writeTheQuestion)

/*#-code-walkthrough(Models.questionInitializer)*/
let question = Question(pages: [
/*#-code-walkthrough(Models.questionInitializer)*/
    QuestionPage( // 0
        /*#-code-walkthrough(Models.questionPageInitializer.multilineStringLiteral)*/
        """
        Welcome to Learn Hockey with Bing Dwen Dwen
        🏒️ 🏒️🏒️ 🏒️
        
        You may have been born in the equator where it never snows, and perhaps haven't had the opportunity to get out of your hometown to go skiing and play hockey. When the Winter Olympics are held, you see the cute Bing Dwen Dwen that have suddenly become popular on the Internet and become curious about ice sports. What will you choose to do?
        """,
        /*#-code-walkthrough(Models.questionPageInitializer.multilineStringLiteral)*/
        /*#-code-walkthrough(Models.questionPageInitializer.choicesArray)*/
        choices: [
            /*#-code-walkthrough(Models.questionPageInitializer.choice)*/
            Choice(text: "Youtube", destination: 1),
            /*#-code-walkthrough(Models.questionPageInitializer.choice)*/
            Choice(text: "TV", destination: 1),
            Choice(text: "I am not interested in this", destination: 2),
        ]
        /*#-code-walkthrough(Models.questionPageInitializer.choicesArray)*/
    ),
    /*#-code-walkthrough(Models.questionPageInitializer.addPage)*/
    QuestionPage( // 1
        """
        There are many videos about snow and ice sports, especially hockey. Do you like it?
        """,
        choices: [
            Choice(text: "I didn't like it because I couldn't understand some of the specialized hockey terminology.", destination: 3),
            Choice(text: "Yes", destination: 5),
//            Choice(text: "Rainbows", destination: 6),
//            Choice(text: "Woodland creatures", destination: 5),
//            Choice(text: "Outer space", destination: 3),
        ]
    ),
    /*#-code-walkthrough(Models.questionPageInitializer.addPage)*/
    QuestionPage( // 2
        """
        Oh no.  May be learn about 🏒️ with Bing Dwen Dwen will make you curious about it.
        """,
        choices: [
        ]
    ),
    QuestionPage( // 3
        """
        Which of the following hockey terms you do not know？
        
        """,
        choices: [
            Choice(text: "Offsides", destination: 4),
            Choice(text: "Icing", destination: 4),
            Choice(text: "Cherry Pick", destination: 4),
        ]
    ),
    QuestionPage( // 4
        """
        Have fun! And you will learn about some hockey terminologies.
        """,
        choices: [
//            Choice(text: "Piped buttercream frosting", destination: 13),
//            Choice(text: "Fondant icing", destination: 7),
        ]
    ),
    QuestionPage( // 5
        """
        Cong! Then maybe you can enjoy cute Bing Dwen Dwen.
        """,
        choices: [
//            Choice(text: "Marzipan figurines", destination: 12),
//            Choice(text: "Fondant figurines", destination: 14),
        ]
    ),
//    QuestionPage( // 6
//        """
//        The judges come around to ask you what you are planning. You tell them all about your rainbow-themed cake. One of the things you tell them is:
//        """,
//        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
//        ]
//    ),
//    QuestionPage( // 7
//        """
//        There is so much available to decorate with; your cake keeps getting better and better. You notice some of your neighbors are using some decorations you didn’t see on the table. What do you do?
//        """,
//        choices: [
//            Choice(text: "Pop over to your neighbor’s bench and ask where they got their toppings.", destination: 16),
//            Choice(text: "Keep working away, your cake will be great even without the specialty item.", destination: 20),
//        ]
//    ),
//    QuestionPage( // 8
//        """
//        You are running out of time, so you put your cake in the freezer to speed things up. You check it after ten minutes. What do you do?
//        """,
//
//        choices: [
//            Choice(text: "Pipe the decorations onto parchment paper. You can transfer them at the last minute.", destination: 17),
//            Choice(text: "Start decorating, you don’t have a minute to waste.", destination: 18),
//        ]
//    ),
//    QuestionPage( // 9
//        """
//        You are feeling good about your timing and start creating your design. You want your theme to come to life, so you decide to upgrade your flat design to become 3D. You head over to the table of supplies and grab:
//        """,
//        choices: [
//            Choice(text: "Marzipan, and lots of it!", destination: 19),
//            Choice(text: "Several bags of different color icing.", destination: 20),
//        ]
//    ),
//    QuestionPage( // 10
//        """
//        When you head to the decorations table to get some candy, you find red, orange, yellow, green, and purple candies, but no blue or indigo! Someone making a troll cake has used all the blue-colored candies. You come in a respectable 4th place, despite your five color rainbow.
//
//        😢 Try again.
//        """,
//        choices: []
//    ),
//    QuestionPage( // 11
//        """
//        The judges say you overbaked your cake and your marshmallow clouds fall flat. You come in 7th place.
//
//        😢 Try again.
//        """,
//        choices: []
//    ),
//    QuestionPage( // 12
//        """
//        Now that the judges have moved on, you are able to get going on your decorations. You start by making all the marzipan figurines. Things are looking pretty good until...you SNEEZE! 🤧🦠 The spray goes everywhere and you have to restart your decorations. In the end, you run out of time and come in 8th place.
//
//        😢 Try again.
//        """,
//        choices: []
//    ),
//    QuestionPage( // 13
//        """
//        The judges come by to ask about your cake. They keep prying for more, and can’t understand why you are only using piped icing. After a short time, you realize you have missed a HUGE part of the directions. You complete the challenge and go home in last place.
//
//        😢 Try again.
//        """,
//        choices: []
//    ),
//    QuestionPage( // 14
//        """
//        Your cake is coming together nicely when a dog bursts into the tent! He runs through, toppling over a tray of your piped decorations. You run out of time to remake them and come in 9th place.
//
//        😢 Try again.
//        """,
//
//        choices: []
//    ),
//    QuestionPage( // 15
//        """
//        Your rainbow turns out magnificent! The arch is sky high and it impresses the judges. You win 2nd place.🥈
//
//        🎉💵You are a cash prize winner!💵🥳
//        """,
//        choices: []
//    ),
//    QuestionPage( // 16
//        """
//        Right before you get to your neighbors bench, you trip on a power cord and knock over their sponge cake! There is no time for them to start over. They are devastated and you decide to disqualify yourself out of solidarity.
//
//        😢 Try again.
//        """,
//        choices: []
//    ),
//    QuestionPage( // 17
//        """
//        Good thinking! You can complete most of your decorations while your cake continues to cool. You work hard and, before you know it, the competition is over and your cake looks spectacular. You come in 3rd place!🥉
//
//        🎉💵You are a cash prize winner!💵🥳
//        """,
//        choices: []
//    ),
//    QuestionPage( // 18
//        """
//        Oh no, you should have waited! All your frosting melts off the sides and your decorations are a disaster. Luckily your cake perfectly baked. The judges are pretty harsh about your decorations and you finish in 6th place.
//
//        😢 Try again.
//        """,
//        choices: []
//    ),
//    QuestionPage( // 19
//        """
//        The judges love your theme and the 3D elements really make it come alive! They compliment you on your mix of chocolate and marzipan. You win 1st place! 🎉🎂🥇
//
//        🎉💵You are a cash prize winner!💵🥳
//        """,
//        choices: []
//    ),
//    QuestionPage( // 20
//        """
//        The judges compliment your theme, but the icing is too thick and overpowers the delicate cake. You come in 5th place.
//
//        😢 Try again.
//        """,
//        choices: []
//    ),
])
