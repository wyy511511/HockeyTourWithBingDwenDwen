import SwiftUI
//#-learning-task(funFactsView)

/*#-code-walkthrough(FunFactsView.funFactsView)*/
struct FunFactsView: View {
    /*#-code-walkthrough(FunFactsView.funFactsView)*/

    /*#-code-walkthrough(FunFactsView.stateVariable)*/
    @State private var funFact = ""
    @State var showingAnimationview = false
    @State private var isLike = false
    /*#-code-walkthrough(FunFactsView.stateVariable)*/
    var body: some View {
        VStack {
//
//            Image("Collin")
//                .resizable()
//                .frame(width: 60, height: 80)
//                .onTapGesture {
//                    //withAnimation {
//                    showingAnimationview.toggle()
//                    //}
//                }
            
            Text("Fun Random Hockey Card")
                .font(.largeTitle)
                .fontWeight(.bold)

//            .padding()
                        
            /*#-code-walkthrough(FunFactsView.textView)*/
            Text(funFact)
                .fontWeight(.bold)
                .foregroundColor(Color.orange)
                .padding()
                .font(.largeTitle)
//                .frame(minHeight: 600)
            Button(funFact){
                self.showingAnimationview.toggle()
            }
            .foregroundColor(Color.yellow)
            
            .sheet(isPresented: $showingAnimationview) {
                if funFact == "team player"{
                    //这个版本可以再加一个关闭按钮
                    TeamPlayerExplained()
                }
                if funFact == "hockey rink"{
                    //这个版本可以再加一个关闭按钮
                    IceHockeyRinkExplained()
                }
                if funFact == "cherry pick"{
                    //这个版本可以再加一个关闭按钮
                    CherrypickExplained()
                }
                if funFact == "offsides"{
                    //这个版本可以再加一个关闭按钮
                    OffsidesExplained()
                }
                if funFact == "Touch icing"{
                    //这个版本可以再加一个关闭按钮
                    TouchIcingExplained()
                }
                if funFact == "No Touch icing"{
                    //这个版本可以再加一个关闭按钮
                    NoTouchIcingExplained()
                }
                if funFact == "Hybrid icing"{
                    //这个版本可以再加一个关闭按钮
                   HybridIcingExplained()
                }


  
                
            }
            
            
            /*#-code-walkthrough(FunFactsView.textView)*/
//            if funFact == "test1"{
//                HomeView()
//            }
            /*#-code-walkthrough(FunFactsView.modifiers)*/
            Button("Show Random Fact") {
                /*#-code-walkthrough(FunFactsView.button)*/
                funFact = information.funFacts.randomElement()!
//                if funFact == "test1"{
//                    HomeView()
//                }
                /*#-code-walkthrough(FunFactsView.button)*/
            }
//            Image(systemName: "Collin")
//            .onTapGesture {
//                self.showingAnimationview.toggle()
//            }
            
            /*#-code-walkthrough(FunFactsView.modifiers)*/
        }

        
//        .background(Color.orange)
//        .opacity(0.5) 不显示图片跟这个没关系
        .padding()
    }
}

struct FunFactsView_Previews: PreviewProvider {
    static var previews: some View {
        FunFactsView()
    }
}
