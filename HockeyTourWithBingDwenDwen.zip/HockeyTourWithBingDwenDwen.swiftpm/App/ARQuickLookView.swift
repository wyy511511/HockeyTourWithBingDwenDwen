

import SwiftUI
import QuickLook
import ARKit

struct ARQuickLookView: UIViewControllerRepresentable {
    var fileName: String
    var allowScaling: Bool 
    func makeCoordinator() -> ARQuickLookView.Coordinator {
        Coordinator(self)
    }
    
    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }
    
    func updateUIViewController(_ controller: QLPreviewController,context: Context) {}
    
    class Coordinator: NSObject, QLPreviewControllerDataSource {
        let parent: ARQuickLookView
        private lazy var fileURL: URL = Bundle.main.url(forResource: parent.fileName,withExtension: "usdz")!
        init(_ parent: ARQuickLookView) {
            self.parent = parent
            super.init()
        }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
            return 1
        }
        func previewController(_ controller: QLPreviewController,previewItemAt index: Int) -> QLPreviewItem {
            guard let filePath = Bundle.main.url(forResource: parent.fileName, withExtension: "usdz") else {fatalError("无法加载模型")}
            let item = ARQuickLookPreviewItem(fileAt: filePath)
            item.allowsContentScaling = parent.allowScaling
            item.canonicalWebPageURL = URL(string: "https://www.example.com/example.usdz")
            return item
        }
    }
}

struct ARQuickLookView_Previews: PreviewProvider {
    static var previews: some View {
        ARQuickLookView(fileName: "untitled",allowScaling:true)
    }
}


