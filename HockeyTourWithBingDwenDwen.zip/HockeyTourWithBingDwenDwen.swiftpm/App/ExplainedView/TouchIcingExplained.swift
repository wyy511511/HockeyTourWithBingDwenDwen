//
//  TouchIcingExplained.swift
//  我的 App
//
//  Created by 吴瑶瑶 on 2022/4/25.
//

import SwiftUI

struct TouchIcingExplained: View {
       @State private var TCnt: CGFloat = 0
       @State private var amount: CGFloat = 1
       @State private var amount1: CGFloat = 1
       var body: some View {

           
           Text("Touch Icing")
               .fontWeight(.bold)
               .foregroundColor(Color.orange)
               .multilineTextAlignment(.center)
                   
           VStack{
               HStack {
                   Button("") {
                      
                   }
                   .foregroundColor(.white)
                   .padding(50)
                   .background(.red)
                   .clipShape(Circle())
                   .overlay {
                       Text("Next")
                       Circle().stroke(.red)
                           .scaleEffect(amount)
                           .opacity(Double(2 - amount))
                           .animation(.easeOut(duration: 1), value: amount)
                   }
                   .onTapGesture {TCnt = TCnt + 1 }
                   .onAppear { amount = 2 }
                   
                   
                   Button("") {}
                   .foregroundColor(.white)
                   .padding(30)
                   .background(.gray)
                   .clipShape(Circle())
                   .overlay {
                       Text("Back")
                       Circle().stroke(.black)
                       
                   }
                   .onTapGesture {TCnt = TCnt - 1 }
                   
                   Button("") {}
                   .foregroundColor(.white)
                   .padding(30)
                   .background(.green)
                   .clipShape(Circle())
                   .overlay {
                       Text("Restart")
                       Circle().stroke(.black)
                   }
                   .onTapGesture {TCnt = 1 }
                   
                   
               }
                   
                       
                       

               
               
               
               Text("🏒️")
               
               if TCnt >= 1{
                   Text("🏒️")
                       .multilineTextAlignment(.leading)
               }
               if TCnt == 2  {


                      Text("Here the infraction is only called once a player on the defending team touches the puck.")
                   
                      Image("ticing0")
                           .resizable()
                           .scaledToFit()

               }
               if TCnt == 3  {

         
                       Image("ticing1")
                       .resizable()
                       .scaledToFit()


   //                    .animation(.easeInOut)
               }
               
//               //"This situation naturally leads to extremely fast head-to-head chases for the puck. To minimize the possibility of  injuries, hybrid icing was recently  introduced."
               if TCnt == 4  {
                    Image("ticing2")
                       .resizable()
                       .scaledToFit()

   //                    .animation(.easeInOut)

               }
               if TCnt == 5  {
                       Image("ticing3")
                       .resizable()
                       .scaledToFit()

               }
               if TCnt == 6  {
                   Text("If the opposition beats them down and touches the puck first, no icing.")
                   Text("This situation naturally leads to extremely fast head-to-head chases for the puck. To minimize the possibility of  injuries, hybrid icing was recently  introduced.")
                  Text("Remember! Icing was made to prevent easy defending")
                      .fontWeight(.bold)
                      .foregroundColor(Color.red)
                      .multilineTextAlignment(.center)


               }
//               if TCnt == 7  {
//                   Text("If the opposition beats them down and touches the puck first, no icing.")
//                   Image("ticing5")
//                       .resizable()
//                       .scaledToFit()
//
//
//               }
//
//               if TCnt == 8  {
//                   Text("If the opposition beats them down and touches the puck first, no icing.")
//                   Image("ticing6")
//                       .resizable()
//                       .scaledToFit()
//
//               }
//
//               if TCnt == 9  {
//                   Text("If the opposition beats them down and touches the puck first, no icing.")
//                   Image("ticing7")
//                       .resizable()
//                       .scaledToFit()
//
//               }
//
//               if TCnt == 10  {
//
//                   Text("Remember! Icing was made to prevent easy defending")
//                       .fontWeight(.bold)
//                       .foregroundColor(Color.red)
//                       .multilineTextAlignment(.center)
//
//               }
//
               
               
           }
           
           
           
           
       }
}

struct TouchIcingExplained_Previews: PreviewProvider {
    static var previews: some View {
        TouchIcingExplained()
    }
}
