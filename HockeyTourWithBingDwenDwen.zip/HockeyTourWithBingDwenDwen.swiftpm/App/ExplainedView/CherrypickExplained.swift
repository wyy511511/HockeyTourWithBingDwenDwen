//
//  File.swift
//  我的 App
//
//  Created by 吴瑶瑶 on 2022/4/24.
//
//
//  CherrypickExplained.swift
//  我的 App
//
//  Created by 吴瑶瑶 on 2022/4/24.
//

import SwiftUI

struct CherrypickExplained: View {
    var body: some View {
        
        VStack{
            
            Text("CHERRY PICK")
                .font(.body)
                .fontWeight(.heavy)
                .foregroundColor(Color.orange)
                .multilineTextAlignment(.center)
                .padding(.top)
            
            Button("Waiting for a pass by the net, for an easy shot at a goal. It's easy for this red man to shot at a goal."){
                
            }.foregroundColor(.yellow)
            
            ZStack{

                    
                Image("cherrypick")
                    .resizable()
                    .scaledToFit()
        
                
                
            }
            
        }

      
    }
}

struct CherrypickExplained_Previews: PreviewProvider {
    static var previews: some View {
        CherrypickExplained()
    }
}
