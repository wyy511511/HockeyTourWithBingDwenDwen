//
//  HybridIcingExplained.swift
//  我的 App
//
//  Created by 吴瑶瑶 on 2022/4/25.
//

import SwiftUI

struct HybridIcingExplained: View {
    var body: some View {
        Text("HybridIcing")
            .font(.largeTitle)
            .fontWeight(.bold)
            .foregroundColor(Color.orange)
            .multilineTextAlignment(.center)
        
        Text("In this form the linesman makes the call himself by analyzing the position of both players in a chase when the first player touches the faceoff dot near the net if the linesman thinks the attacking team will touch the puck first play continues the chase goes on ")
            .font(.body)
            .fontWeight(.bold)
            .foregroundColor(Color.orange)
            .multilineTextAlignment(.leading)
        
        ScrollView{
            Image("hicing0")
                .resizable()
                .scaledToFit()
            Image("hicing1")
                .resizable()
                .scaledToFit()
            Image("hicing3")
                .resizable()
                .scaledToFit()
            Image("hicing4")
                .resizable()
                .scaledToFit()
            Image("hicing5")
                .resizable()
                .scaledToFit()
        }
        
    }
}

struct HybridIcingExplained_Previews: PreviewProvider {
    static var previews: some View {
        HybridIcingExplained()
    }
}
