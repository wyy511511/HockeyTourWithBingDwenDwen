//
//  NoTouchIcingExplained.swift
//  我的 App
//
//  Created by 吴瑶瑶 on 2022/4/25.
//

import SwiftUI

struct NoTouchIcingExplained: View {
    var body: some View {
        ScrollView{
            Text("No Touch Icing")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(Color.orange)
                .multilineTextAlignment(.center)
            
            Text("If offsides were created to prevent easy scoring,icing was made to prevent easy defending")
                .multilineTextAlignment(.leading)
            
            Text(" To illustrate icing we only need to look at the Main Center red line and then the two goal lines.")
                .multilineTextAlignment(.leading)
            
                Image("nticing1")
                .resizable()
                .scaledToFit()
           
            Text("If a player shoots the puck from behind their side of the red line and it passes the opponent's goal line that's icing .")
                .multilineTextAlignment(.leading)
            Text("This particular form of icing is called automatic or no touch icing.")
                .multilineTextAlignment(.leading)
            Text("The linesman blows the whistle and a faceoff takes place in the defensive zone of the offending team the one that  shot it down the ice")
                .multilineTextAlignment(.leading)
            
            
        }
    }
}

struct NoTouchIcingExplained_Previews: PreviewProvider {
    static var previews: some View {
        NoTouchIcingExplained()
    }
}
