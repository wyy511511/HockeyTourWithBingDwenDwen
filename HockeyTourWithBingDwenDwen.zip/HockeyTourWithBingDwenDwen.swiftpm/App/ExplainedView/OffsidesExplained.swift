//
//  OffsidesExplained.swift
//  我的 App
//
//  Created by 吴瑶瑶 on 2022/4/24.
//

import SwiftUI

struct OffsidesExplained: View {
    @State private var offsidesCnt: CGFloat = 0
    @State private var amount: CGFloat = 1
    @State private var amount1: CGFloat = 1
    var body: some View {

          
                
//                Button("Back") {}
//                .foregroundColor(.white)
//                .padding(30)
//                .background(.gray)
//                .clipShape(Circle())
//                .onTapGesture {
//                    offsidesCnt = offsidesCnt - 1
//                }
            Text("Offsides")
                .fontWeight(.bold)
                .foregroundColor(Color.orange)
                .multilineTextAlignment(.center)
                
        VStack{
            HStack {
                Button("") {
                   
                }
                .foregroundColor(.white)
                .padding(50)
                .background(.red)
                .clipShape(Circle())
                .overlay {
                    Text("Next")
                    Circle().stroke(.red)
                        .scaleEffect(amount)
                        .opacity(Double(2 - amount))
                        .animation(.easeOut(duration: 1), value: amount)
                }
                .onTapGesture {offsidesCnt = offsidesCnt + 1 }
                .onAppear { amount = 2 }
                
                
                Button("") {}
                .foregroundColor(.white)
                .padding(30)
                .background(.gray)
                .clipShape(Circle())
                .overlay {
                    Text("Back")
                    Circle().stroke(.black)
                    
                }
                .onTapGesture {offsidesCnt = offsidesCnt - 1 }
                
                Button("") {}
                .foregroundColor(.white)
                .padding(30)
                .background(.green)
                .clipShape(Circle())
                .overlay {
                    Text("Restart")
                    Circle().stroke(.black)
                }
                .onTapGesture {offsidesCnt = 1 }
                
                
            }
                
                    
                    

            
            
            
            Text("In hockey, offsides are there to prevent cherry picking ")
            
            if offsidesCnt >= 1{
                Text("Attacking players can only enter the offensive zone once the puck has entered first ")
                    .multilineTextAlignment(.leading)
            }
            if offsidesCnt == 2  {
                Image("offsides1")
                    .resizable()
                    .scaledToFit()
                 
                Text("These 2 red attacking players are moving forward")
            }
            if offsidesCnt == 3  {
                
                Text("These 2 red attacking players are moving forward")
                Image("offsides2")
                    .resizable()
                    .scaledToFit()
//                    .animation(.easeInOut)
            }
            if offsidesCnt == 4  {
                
                
                Image("offsides3")
                    .resizable()
                    .scaledToFit()
//                    .animation(.easeInOut)
                Text("The puck has entered first!")
            }
            if offsidesCnt == 5  {
                Image("offsides4")
                    .resizable()
                    .scaledToFit()
//                    .animation(.easeInOut)
                Text("The attacking player has entered first!")
                
            }
            if offsidesCnt == 6  {
                Image("offsides5")
                    .resizable()
                    .scaledToFit()
//                    .animation(.easeInOut)
                Text("The attacking player has entered first!")
                
            }
            if offsidesCnt == 7  {
                Text("When an offside does occur play is stopped by the lines been blowing their whistle and in most cases a faceoff takes place just outside the offensive zone.")
                    .multilineTextAlignment(.leading)
                Image("offsides6")
                    .resizable()
                    .scaledToFit()
//                    .animation(.easeInOut)
                
                
            }
            
            if offsidesCnt == 8  {
                Text("Remember! Offsides were created to prevent easy scoring.")
                    .fontWeight(.bold)
                    .foregroundColor(Color.red)
                    .multilineTextAlignment(.center)
                     
            }
            
            
        }
        
        
        
        
    }
}




struct OffsidesExplained_Previews: PreviewProvider {
    static var previews: some View {
        OffsidesExplained()
    }
    
}
