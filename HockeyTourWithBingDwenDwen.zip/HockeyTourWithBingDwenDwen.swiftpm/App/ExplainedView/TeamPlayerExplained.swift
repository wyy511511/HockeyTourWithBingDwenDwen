//
//  SwiftUIView.swift
//  
//
//  Created by 吴瑶瑶 on 2022/4/24.
//

import SwiftUI

struct TeamPlayerExplained: View {
    @State private var movexD: CGFloat = 0
    @State private var moveyD: CGFloat = 0
    
    @State var showingGoaltender = false
    @State var showing2dfman = false
    @State private var showingLeftwing = false
    @State private var showingCenter = false
    @State private var showingRightwing = false

        
       
        var body: some View {
            VStack{
                VStack {
                    Text("Six Players")
                        .fontWeight(.bold)
                        .foregroundColor(Color.orange)
                        .multilineTextAlignment(.center)
                    
                    Button("Tap to show all players"){
                        if showing2dfman == false{
                            showing2dfman.toggle()
                        }
                        if showingLeftwing == false{
                            showingLeftwing.toggle()
                        }
                                
                        if showingRightwing == false{
                            showingRightwing.toggle()
                        }
                        if showingCenter == false{
                           showingCenter.toggle()
                        }
                       if showingGoaltender == false{
                           showingGoaltender.toggle()
                       }
                        
                    }

                    
                    VStack {
                        Text("Three forwards")
                        HStack(){
                            Button("a left winger"){
                                showingLeftwing.toggle()
                            }
                            Button("a right winger"){
                                showingRightwing.toggle()
                            }
                            Button("a center"){
                                showingCenter.toggle()
                            }
                            
                            
                        }
                    }
                    .foregroundColor(Color.orange)
                    
                    
                    
                    Button("two defenseman"){
                        self.showing2dfman.toggle()
                    }
                        .padding(.all)
                        .background(Color.yellow)
                    
                    
                    
                    Button("Goaltender/goalie "){
                        self.showingGoaltender.toggle()
                    }
                        .padding(.all)
                        .background(Color.yellow)
                    
                }
                
                
                VStack(spacing: 20) {
                  
                        
                    Image("net")
    //                    .scaledToFit()
                        .resizable()
                        .scaledToFit()
                        .padding([.top, .leading, .trailing])
                        .frame(width: 200.0,height: 100.0)
    //                        .offset(x: movexD, y: moveyD)// 把这个从10改到150才意识到这个大概只是起点。以及 y的150幅度小于x的80
                        //缓进缓出easeInOut
                        .animation(.easeIn(duration: 4), value: movexD)
                    Spacer()

                    
                    if showingGoaltender {
                        Image("goaltender")
                            .resizable()
                            .padding(.leading, 0.0)
                            .scaledToFit()
                            .frame(width: 80,height: 90)
                    }
                    
                    HStack {
                        if showing2dfman{
                            Spacer()
                            Image("player")
                                .resizable()
                                .padding(.leading, 0.0)
                                .scaledToFit()
                                .frame(width: 50,height: 70)
        ////                        .offset(x: movexD, y: moveyD)// 把这个从10改到150才意识到这个大概只是起点。以及 y的150幅度小于x的80
        //                        //缓进缓出easeInOut
        //                        .animation(.easeIn(duration: 4), value: movexD)
                            Spacer()

             
                            Image("player")
                                .resizable()
                                .padding(.trailing, 0.0)
                                .scaledToFit()
                            .frame(width: 50,height: 70)

                        
                            Spacer()
                        }

                    }
                    
                    HStack {
                        Image(showingLeftwing ? "player" : "playerplaceholder")
                            .resizable()
                            .padding(.leading, 0.0)
                            .scaledToFit()
                            .frame(width: 50,height: 70)
    ////                        .offset(x: movexD, y: moveyD)// 把这个从10改到150才意识到这个大概只是起点。以及 y的150幅度小于x的80
    //                        //缓进缓出easeInOut
    //                        .animation(.easeIn(duration: 4), value: movexD)
                        Spacer()
                        VStack {
                            Spacer()
                                .frame(height: 100.0)
                            Image(showingCenter ? "player" : "playerplaceholder")
                                .resizable()
                                .padding(.trailing, 0.0)
                                .scaledToFit()
                            .frame(width: 50,height: 70)
                        }
                        
                        Spacer()
                        Image(showingRightwing ? "player" : "playerplaceholder")
                            .resizable()
                            .padding(.trailing, 0.0)
                            .scaledToFit()
                            .frame(width: 50,height: 70)
                    }
                    
    //
    //                Button("点击移动爱心") {
    //                    movexD += 80
    //                    moveyD += 80
    //
    //                }.font(.title)
                    
                }
            }
        }
        
}


struct TeamPlayerExplained_Previews: PreviewProvider {
    static var previews: some View {
        TeamPlayerExplained()
    }
}
