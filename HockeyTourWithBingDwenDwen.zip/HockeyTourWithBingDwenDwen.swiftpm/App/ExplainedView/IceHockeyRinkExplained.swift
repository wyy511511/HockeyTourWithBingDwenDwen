//
//  IceHockeyRinkExplained.swift
//  About Me
//
//  Created by 吴瑶瑶 on 2022/4/25.
//

import SwiftUI

struct IceHockeyRinkExplained: View {
    @State private var offsidesCnt1: CGFloat = 1
    @State private var amount: CGFloat = 1
    @State private var amount1: CGFloat = 1
    var body: some View {

          
                
//                Button("Back") {}
//                .foregroundColor(.white)
//                .padding(30)
//                .background(.gray)
//                .clipShape(Circle())
//                .onTapGesture {
//                    offsidesCnt = offsidesCnt - 1
//                }
            Text("Ice Hockey Rink")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(Color.orange)
                .multilineTextAlignment(.center)
                
        VStack{
            HStack {
                Button("") {
                   
                }
                .foregroundColor(.white)
                .padding(50)
                .background(.red)
                .clipShape(Circle())
                .overlay {
                    Text("Next")
                    Circle().stroke(.red)
                        .scaleEffect(amount)
                        .opacity(Double(2 - amount))
                        .animation(.easeOut(duration: 1), value: amount)
                }
                .onTapGesture {offsidesCnt1 = offsidesCnt1 + 1 }
                .onAppear { amount = 2 }
                
                
                Button("") {}
                .foregroundColor(.white)
                .padding(30)
                .background(.gray)
                .clipShape(Circle())
                .overlay {
                    Text("Back")
                    Circle().stroke(.black)
                    
                }
                .onTapGesture {offsidesCnt1 = offsidesCnt1 - 1 }
                
                Button("") {}
                .foregroundColor(.white)
                .padding(30)
                .background(.green)
                .clipShape(Circle())
                .overlay {
                    Text("Restart")
                    Circle().stroke(.black)
                }
                .onTapGesture {offsidesCnt1 = 1 }
                
                
            }
                
                    
                    

            
            
            
            Text("🏒️")
        
                if offsidesCnt1 >= 1{
                    Text("🏒️")
  
         
                }
                if offsidesCnt1 == 2  {
    //                Image("offsides1")
    //                    .resizable()
    //                    .scaledToFit()
                    Text("In North America a standard ice hockey rink is 200 feet long by 85 feet wide.")
                        .multilineTextAlignment(.leading)
                    Image("playground1")
                        .resizable()
                        .scaledToFit()
    //

                }
                if offsidesCnt1 == 3  {
                    Text(" How does that compare to other sports?")
                    Text("You could also fit around three rinks into either a football or soccer field.")
                    Image("playground2")
                        .resizable()
                        .scaledToFit()
    //                    .animation(.easeInOut)
                }
                if offsidesCnt1 == 4  {


                    Image("playground3")
                        .resizable()
                        .scaledToFit()
    //                    .animation(.easeInOut)
                    Text(" But it's not the smallest surface in major sports you could fit almost four basketball courts onto one hockey rink.")
                }
//                if offsidesCnt1 == 5  {
//
//                    Text("now let's start putting the lines on the ice.")
//
//                }
//                if offsidesCnt1 == 6  {
//                    Text("now let's start putting the lines on the ice.")
//                    Text("First, right in the middle is the center line ")
//
//                }
                if offsidesCnt1 == 5  {
                    Text("now let's start putting the lines on the ice.")
                    Text("First, right in the middle is the center line ")
                    Text("Next there are two blue lines that divide the rink into three zones, the neutral zone and two end zones. And finally a goal line at each end.")
                        .multilineTextAlignment(.leading)
                }
//    //
//                if offsidesCnt1 == 8  {
//                    Text("Now let's add the faceoff dots.")
//                        .fontWeight(.bold)
//                        .foregroundColor(Color.red)
//                        .multilineTextAlignment(.center)
//
//                    Image("playground")
//                        .resizable()
//                        .scaledToFit()
            //可能是这个图或者这里的重复导致的问题
//
//                }
                if offsidesCnt1 == 6  {
                    Text("There's nine faceoff spots on the ice. One it's Center two in each end zone and four in the neutral zone.")

                        .multilineTextAlignment(.center)


                }
//    //
                if offsidesCnt1 == 7  {
                    Text("The last thing is the oles crease this is basically the goalies home at the beginning of the first period . Teams line up for a faceoff at center, the referee drops the puck and the game begins.")

                        .multilineTextAlignment(.center)

                }
//                if offsidesCnt1 == 11  {
//                    Text(" Well, that's about enough to start enjoying the great game of hockey for now! ")
//                        .fontWeight(.bold)
//                        .foregroundColor(Color.red)
//                        .multilineTextAlignment(.center)
//
//
//                }
    //
            
            
   
        
            
            
        }
        
        
        
        
    }
}

struct IceHockeyRinkExplained_Previews: PreviewProvider {
    static var previews: some View {
        IceHockeyRinkExplained()
    }
}
